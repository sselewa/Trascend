module.exports = {
  publicPath: "./",
  outputDir: "build",
};
