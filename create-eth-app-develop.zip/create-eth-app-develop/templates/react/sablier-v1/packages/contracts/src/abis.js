import erc20 from "./abis/erc20.json";
import payroll from "./abis/payroll.json";
import sablier from "./abis/sablier.json";

export default {
  erc20,
  payroll,
  sablier,
};
