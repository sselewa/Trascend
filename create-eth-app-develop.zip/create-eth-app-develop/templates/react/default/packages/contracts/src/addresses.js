// This address points to a dummy ERC-20 contract. Replace it with your own smart contracts.
const addresses = {
  ceaErc20: "0xa6dF0C88916f3e2831A329CE46566dDfBe9E74b7",
};
export default addresses;
