import readProxy from "./abis/readProxy.json";
import SNX from "./abis/snx.json";

export default {
  readProxy,
  tokens: {
    SNX,
  },
};
