declare module "promisepipe";
